/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.awt.GridLayout;
import java.awt.TextField;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ConversorMedidasGUI extends JFrame {
    private TextField campoValor;
    private JComboBox<String> comboConversao;
    private JCheckBox radioIda,radioVolta;
    private ButtonGroup grupoDirecao;
    private JLabel labelResultado;
    
    public ConversorMedidasGUI() {
        setTitle("Conversor Medidas");
        setSize(400,300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(6,1));
        
        setVisible(true);

        //campo de entrada 
        JPanel painelEntrada = new JPanel();
        painelEntrada.add(new JLabel ("Valor: "));
        campoValor = new TextField(10);
        painelEntrada.add(campoValor);
        add(painelEntrada);


        //criando conversao dropbox
        JPanel painelCombo = new JPanel();
        painelCombo.add(new JLabel("Conversão: "));
        String[] opcao = {
            "Metros <-> Centímetros",
            "Quilometros <-> Milhas",
            "Polegadas <-> Centimetros"
        };

        comboConversao = new JComboBox<>(opcao);
        painelCombo.add(comboConversao);
        add(painelCombo);



    }       

}